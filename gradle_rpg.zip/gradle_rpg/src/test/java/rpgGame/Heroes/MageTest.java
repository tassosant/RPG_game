package rpgGame.Heroes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MageTest{

    @Test
    void testGetName() {
    }

    @Test
    void testGetLevel() {
    }

    @Test
    void testSetLevel() {
    }

    @Test
    void testSetLevelAttributes() {
    }

    @Test
    void testGetLevelAttributes() {
    }

    @Test
    void testLevelUp() {
    }

    @Test
    void testDisplay() {
    }

    @Test
    void testTotalAttributes() {
    }

    @Test
    void testEquipArmor() {
    }

    @Test
    void testEquipWeapon() {
    }

    @Test
    void testDamage() {
    }

    @Test
    void testAddWeaponTypes() {
    }

    @Test
    void testAddArmorTypes() {
    }

    @Test
    void testInitEquipmentSlots() {
    }

    @Test
    void testDropWeapon() {
    }

    @Test
    void testDropArmor() {
    }

    @Test
    void testLevelUp1() {
    }

    @Test
    void testDamage1() {
    }
}