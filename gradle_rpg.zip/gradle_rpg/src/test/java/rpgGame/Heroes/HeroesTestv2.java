package rpgGame.Heroes;

import org.junit.jupiter.api.Test;

public class HeroesTestv2 {


}
