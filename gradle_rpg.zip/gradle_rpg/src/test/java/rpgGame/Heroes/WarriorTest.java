package rpgGame.Heroes;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class WarriorTest {

    @Test
    void getName() {
    }

    @Test
    void getLevel() {
    }

    @Test
    void setLevel() {
    }

    @Test
    void setLevelAttributes() {
    }

    @Test
    void getLevelAttributes() {
    }

    @Test
    void levelUp() {
    }

    @Test
    void display() {
    }

    @Test
    void totalAttributes() {
    }

    @Test
    void equipArmor() {
    }

    @Test
    void equipWeapon() {
    }

    @Test
    void damage() {
    }

    @Test
    void addWeaponTypes() {
    }

    @Test
    void addArmorTypes() {
    }

    @Test
    void initEquipmentSlots() {
    }

    @Test
    void dropWeapon() {
    }

    @Test
    void dropArmor() {
    }

    @Test
    void testLevelUp() {
    }

    @Test
    void testDamage() {
    }
}